<?php
$servername = "localhost";
$username = "newuser";  // The new username you created
$password = "vi@WE2305";  // The new password you created
$dbname = "WIMS2021";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $mobileNo = $_POST['mobileNo'];
    $gender = $_POST['gender'];

    $sql = "INSERT INTO users (FirstName, LastName, EmailAddress, Password, Address, MobileNo, Gender) 
            VALUES ('$firstName', '$lastName', '$email', '$password', '$address', '$mobileNo', '$gender')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration Successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
