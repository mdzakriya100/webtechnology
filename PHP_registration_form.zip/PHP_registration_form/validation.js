function validateForm() {
    var firstName = document.forms["registrationForm"]["firstName"].value;
    var lastName = document.forms["registrationForm"]["lastName"].value;
    var email = document.forms["registrationForm"]["email"].value;
    var password = document.forms["registrationForm"]["password"].value;
    var confirmPassword = document.forms["registrationForm"]["confirmPassword"].value;
    var address = document.forms["registrationForm"]["address"].value;
    var mobileNo = document.forms["registrationForm"]["mobileNo"].value;
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    var passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;

    if (!/^[a-zA-Z]{6,}$/.test(firstName)) {
        alert("First Name should contain alphabets and be at least 6 characters long.");
        return false;
    }

    if (lastName === "") {
        alert("Last Name should not be empty.");
        return false;
    }

    if (address === "") {
        alert("Address should not be empty.");
        return false;
    }

    if (!passwordPattern.test(password)) {
        alert("Password should be at least 6 characters long, contain one uppercase letter, one lowercase letter, one number, and one special character.");
        return false;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    if (!emailPattern.test(email)) {
        alert("Invalid email address.");
        return false;
    }

    if (!/^\d{10}$/.test(mobileNo)) {
        alert("Mobile number should be exactly 10 digits.");
        return false;
    }

    return true;
}
