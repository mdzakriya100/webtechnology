function validateForm() {
  var firstName = document.getElementById("firstName").value;
  var lastName = document.getElementById("lastName").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  var address = document.getElementById("address").value;
  var mobile = document.getElementById("mobile").value;

  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var mobilePattern = /^\d{10}$/;

  if (!firstName.match(/^[a-zA-Z]{6,}$/)) {
    alert(
      "First Name should contain only alphabets and be at least 6 characters long."
    );
    return false;
  }

  if (lastName.trim() === "") {
    alert("Last Name should not be empty.");
    return false;
  }

  if (!email.match(emailPattern)) {
    alert("Please enter a valid email address (e.g., name@domain.com).");
    return false;
  }

  if (password.length < 6) {
    alert("Password should be at least 6 characters long.");
    return false;
  }

  if (password !== confirmPassword) {
    alert("Password and Confirm Password should be the same.");
    return false;
  }

  if (address.trim() === "") {
    alert("Address should not be empty.");
    return false;
  }

  if (!mobile.match(mobilePattern)) {
    alert("Mobile Number should contain exactly 10 digits.");
    return false;
  }

  alert("Form submitted successfully!");
}
